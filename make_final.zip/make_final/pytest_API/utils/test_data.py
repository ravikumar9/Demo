# Default username and password for ReqRes mock authentication
LOGIN_CREDENTIALS = {
    "email": "eve.holt@reqres.in",
    "password": "cityslicka"
}

USER_DATA = {
    "name": "John Doe",
    "job": "Software Engineer"
}

UPDATED_USER_DATA = {
    "name": "Jane Doe",
    "job": "Senior Software Engineer"
}
